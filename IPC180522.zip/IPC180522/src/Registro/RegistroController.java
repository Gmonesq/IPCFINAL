/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Registro;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author kalez
 */
public class RegistroController implements Initializable {
    
    @FXML //Botón seleccionar avatar
    private Button avatarBtn;
    @FXML
    private TextField userTextRegister;
    @FXML //cuadro de etxto para introducir contraseña
    private TextField passwordTextRegister;
    @FXML //Cuador de texto para introducir email
    private TextField emailTextRegister;
    @FXML //Seleccionador de fecha de nacimiento
    private DatePicker birthTextRegister;
    @FXML //Botón enviar
    private Button enviarBtnRegister;
    @FXML //Botón borrar
    private Button borrarBtnRegister;
    @FXML
    private Text userLabel;
    @FXML
    private Text passwordLabel;
    @FXML
    private Text birthLabel;
    @FXML
    private Text emailLabel;
    //list for special characters
    ArrayList<String> listSpecial = new ArrayList<String>();
    ArrayList<String> listDigits = new ArrayList<String>();

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //initialization of the list of special characters
        listSpecial.add("!");
        listSpecial.add("@");
        listSpecial.add("#");
        listSpecial.add("$");
        listSpecial.add("%");
        listSpecial.add("&");
        listSpecial.add("*");
        listSpecial.add("(");
        listSpecial.add(")");
        listSpecial.add("-");
        listSpecial.add("+");
        listSpecial.add("=");
        //initialization for all the digits
        for(int i=1; i<=9; i++){
            listDigits.add("" + i);
        }
    }    

    @FXML
    private void handleOnActionEnviarBtnRegister(ActionEvent event) throws IOException {
        String userValue = userTextRegister.textProperty().getValueSafe();
        String passValue = passwordTextRegister.textProperty().getValueSafe();
        // check if input datas are accepted by the system
        
        //CHECK USERNAME
        if(userValue.length() < 6 || userValue.length() > 15 || userValue.contains(" ")){
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Username error");
            alert.setContentText("Please insert a string of 6 to 15 characters, "
                    + "including underscores or dash, but without any space");
            alert.showAndWait();
            
        //CHECK PASSWORD
        
        } else if(passValue.length() < 8 || passValue.length() > 20 || !containsSpecialCharacters(passValue)
                || !containsDigits(passValue) || !containsUpperCase(passValue) || !containsLowerCase(passValue)){
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Password error");
            alert.setContentText("Please insert a string of 8 to 20 characters "
                    + "containing at least: 1 upper case and 1 lower case character, 1 digit, "
                    + "1 special character (!@#$%&*()-+=)");
            alert.showAndWait();
        } else { //(missing checking email (with UtilsClass) and the birth date
            Alert alert = new Alert(AlertType.CONFIRMATION);
            alert.setTitle("Confirmation");
            alert.setHeaderText("Are you sure?");
            alert.setContentText("Please check datas before pressing OK");
            Optional<ButtonType> result = alert.showAndWait(); // result of interaction with alert (OK/Cancel)
            if(result.isPresent() && result.get() == ButtonType.OK){ // if OK is pressed
                FXMLLoader myLoader = new FXMLLoader(getClass().getResource("/poiupv/FXML_mapa.fxml")); // open the map
                Parent root = myLoader.load();
                Scene scene = new Scene(root);
                Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                stage.setScene(scene);
                stage.setTitle("Mapa");
                stage.show();
            }
        }
        
    }
    //check if string contains any special character
    private boolean containsSpecialCharacters(String pass){
        boolean result = false;
        for(int i=0; i<listSpecial.size();i++){
            if(pass.contains(listSpecial.get(i))){
                result = true;
            }
        }
        return result;
    }
    //check if string contains any digits
    private boolean containsDigits(String pass){
        boolean result = false;
        for(int i=0; i<listDigits.size();i++){
            if(pass.contains(listDigits.get(i))){
                result = true;
            }
        }
        return result;
    }
    //check if string contains any upperCase character
    private boolean containsUpperCase(String pass){
        boolean result = false;
        for(int i=0; i < pass.length(); i++){
            if(Character.isUpperCase(pass.charAt(i))){
                result = true;
            }
        }
        return result;
    }
    //check if string contains any lowerCase character
    private boolean containsLowerCase(String pass){
        boolean result = false;
        for(int i=0; i < pass.length(); i++){
            if(Character.isLowerCase(pass.charAt(i))){
                result = true;
            }
        }
        return result;
    }
    @FXML
    private void handleOnActionBorrarBtnRegister(ActionEvent event) {
    }

    @FXML
    private void handleOnActionAvatarBtn(ActionEvent event) {
    }
    
}
