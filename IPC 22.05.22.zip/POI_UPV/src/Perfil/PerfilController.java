/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Perfil;

import DBAccess.NavegacionDAOException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.URL;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.Set;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.User;
import poiupv.FXML_mapaController;
import poiupv.Utils;

/**
 * FXML Controller class
 *
 * @author DMATTAR
 */
public class PerfilController implements Initializable {

    @FXML
    private Text userTextEditProfile;
    @FXML
    private ImageView imageEditProfile;
    @FXML
    private PasswordField passwordActualTextEdit;
    @FXML
    private PasswordField passwordNewTextEdit;
    @FXML
    private TextField emailTextEdit;
    @FXML
    private DatePicker birthTextEdit;
    @FXML
    private Text volverMapaTextEdit;
    @FXML
    private Label passwordActualTextEditWarning;
    @FXML
    private Label passwordNewTextEditWarning;
    @FXML
    private Label emailTextEditWarning;
    @FXML
    private Label birthTextEditWarning;
    @FXML
    private Button actualizarBtn;
    
    private User userObj;
    private Image newAvatar;
    private BooleanProperty validPass;
    private BooleanProperty validEmail;
    private BooleanProperty validDate;
    private BooleanBinding validCredentials;


    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        //INIT BOOLEAN PROPERTIES && BINDINGS
        validPass = new SimpleBooleanProperty();
        validEmail = new SimpleBooleanProperty();
        validDate = new SimpleBooleanProperty();
        validPass.setValue(Boolean.TRUE); //INIT TO TRUE IN CASE USER DOES NOT WANT TO CHANGE PASS
        validEmail.setValue(Boolean.TRUE);
        validDate.setValue(Boolean.TRUE);
        validCredentials = Bindings.and(validPass, validEmail).and(validDate);
        actualizarBtn.disableProperty().bind(Bindings.not(validCredentials));

        
        //add Listener for checking passwordActualTextEdit
        passwordActualTextEdit.textProperty().addListener((observable, oldValue, newValue) -> {
            passwordActualTextEditWarning.visibleProperty().setValue(Boolean.FALSE);
            passwordActualTextEdit.setStyle("-fx-border-color: default");
        });
        
        //add Listener for checking passwordNewTextEdit
        passwordNewTextEdit.focusedProperty().addListener((observable, oldValue, newValue) -> {
            String passValue = passwordNewTextEdit.textProperty().getValueSafe();
            if(!newValue){ // if focus is taken off
                if(passValue.isEmpty()){
                    passwordNewTextEditWarning.visibleProperty().setValue(Boolean.FALSE);
                    passwordNewTextEdit.setStyle("-fx-border-color: default");
                    validPass.setValue(Boolean.TRUE);
                } else if(!Utils.checkPassword(passValue) || passValue == userObj.getPassword()){
                    passwordNewTextEditWarning.visibleProperty().setValue(Boolean.TRUE);
                    passwordNewTextEdit.setStyle("-fx-border-color: red");
                    validPass.setValue(Boolean.FALSE);
                } else {
                    passwordNewTextEditWarning.visibleProperty().setValue(Boolean.FALSE);
                    passwordNewTextEdit.setStyle("-fx-border-color: default");
                    validPass.setValue(Boolean.TRUE);
                }}
        });
        
        //add Listener for checking emailTextEdit
        emailTextEdit.focusedProperty().addListener((observable, oldValue, newValue) -> {
            String email = emailTextEdit.textProperty().getValueSafe();
            if(!newValue){ // if focus is taken off
                if(!Utils.checkEmail(email)){
                    emailTextEditWarning.visibleProperty().setValue(Boolean.TRUE);
                    emailTextEdit.setStyle("-fx-border-color: red");
                    validEmail.setValue(Boolean.FALSE);
                } else {
                    emailTextEditWarning.visibleProperty().setValue(Boolean.FALSE);
                    emailTextEdit.setStyle("-fx-border-color: default");
                    validEmail.setValue(Boolean.TRUE);
                }}
        });
        
        //add Listener for checking birthTextEdit
        birthTextEdit.focusedProperty().addListener((observable, oldValue, newValue) -> {
            LocalDate date = birthTextEdit.valueProperty().getValue();
            if(!newValue){ // if focus is taken off
                if(!Utils.checkBirthDate(date)){
                    birthTextEditWarning.visibleProperty().setValue(Boolean.TRUE);
                    birthTextEdit.setStyle("-fx-border-color: red");
                    validDate.setValue(Boolean.FALSE);
                } else {
                    birthTextEditWarning.visibleProperty().setValue(Boolean.FALSE);
                    birthTextEdit.setStyle("-fx-border-color: default");
                    validDate.setValue(Boolean.TRUE);
                }}
        });
        
        
    }    
    
    public void initData(User usuario){
        userObj = usuario;
        userTextEditProfile.textProperty().setValue(userObj.getNickName());
        emailTextEdit.textProperty().setValue(userObj.getEmail());
        birthTextEdit.valueProperty().setValue(userObj.getBirthdate());
        imageEditProfile.imageProperty().setValue(userObj.getAvatar());
        
    }
    @FXML
    private void handleOnActionUploadImageBtn(ActionEvent event) throws FileNotFoundException {
        FileChooser file = new FileChooser();
        file.setTitle("Abrir fichero");
        file.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("Images", "*.png", "*.jpg", "*.gif"));
        File selectedFile = file.showOpenDialog(
                ((Node) event.getSource()).getScene().getWindow());
        String url = selectedFile.getAbsolutePath();
        newAvatar = new Image(new FileInputStream(url));
        imageEditProfile.imageProperty().setValue(newAvatar);
    }

    @FXML //UPDATE NEW DATA IN USER PROFILE
    private void handleOnActionActualizarBtn(ActionEvent event) throws NavegacionDAOException {
        String currentPass = passwordActualTextEdit.textProperty().getValueSafe();
        String newPass = passwordNewTextEdit.textProperty().getValueSafe();
        String newEmail = emailTextEdit.textProperty().getValueSafe();
        LocalDate newBirthDate = birthTextEdit.valueProperty().getValue();
        Stage perfilStage = ((Stage)((Node)event.getSource()).getScene().getWindow()); //current Stage
        Alert alertConf = new Alert(AlertType.CONFIRMATION);
            alertConf.setTitle("Confirmación");
            alertConf.setHeaderText("¿Estás seguro?");
            alertConf.setContentText("Por favor, revisa los datos antes de pulsar OK");
            Optional<ButtonType> result = alertConf.showAndWait(); // result of interaction with alert (OK/Cancel)
            if(result.isPresent() && result.get() == ButtonType.OK){ // if OK is pressed
                
                //IF USER ALSO WANTS TO CHANGE THE PASSWORD
                if(!(newPass.isEmpty())){
                    
                    //IF USER INSERTED CORRECT CURRENT PASSWORD
                    if(currentPass.equals(userObj.getPassword())){
                        userObj.setPassword(newPass);
                        userObj.setEmail(newEmail);
                        userObj.setBirthdate(newBirthDate);
                        userObj.setAvatar(newAvatar);
                        perfilStage.close(); //CLOSE THE EDIT PROFILE WINDOW
                        Alert alertInfo = new Alert(AlertType.INFORMATION);
                        alertInfo.setTitle("Informacion");
                        alertInfo.setContentText("Cambios aplicados con éxito");
                        alertInfo.show();
                        //UPLOAD THE CURRENT MAP WITH NEW USER DATA
                        FXMLLoader loader = new FXMLLoader(getClass().getResource("/poiupv/FXML_mapa.fxml"));
                        FXML_mapaController mapController = loader.<FXML_mapaController>getController();
                        mapController.initUser(userObj);
                        
                    } else { //IF USER INSERTED WRONG CURRENT PASSWORD
                        
                        passwordActualTextEditWarning.visibleProperty().setValue(Boolean.TRUE);
                        passwordActualTextEdit.setStyle("-fx-border-color: red");
                        Alert alertError = new Alert(AlertType.ERROR);
                        alertError.setTitle("Error");
                        alertError.setHeaderText("Contraseña actual incorrecta");
                        alertError.setContentText("Para establecer una nueva contraseña, debe ingresar"
                                                    + " su contraseña actual correctamente");
                        alertError.show();
                    }
                    
                //IF USER DOES NOT WANT TO CHANGE THE PASSWORD  
                } else {
                    userObj.setEmail(newEmail);
                    userObj.setBirthdate(newBirthDate);
                    userObj.setAvatar(newAvatar);
                    perfilStage.close(); //CLOSE THE EDIT PROFILE WINDOW
                    Alert alertInfo = new Alert(AlertType.INFORMATION);
                    alertInfo.setTitle("Informacion");
                    alertInfo.setHeaderText("Cambios aplicados con éxito");
                    alertInfo.setContentText("Para actualizar correctamente los cambios, por favor reinicia la aplicación");
                    alertInfo.show();
                    //UPLOAD THE CURRENT MAP WITH NEW USER DATA
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/poiupv/FXML_mapa.fxml"));
                    FXML_mapaController mapController = loader.<FXML_mapaController>getController();
                    mapController.initUser(userObj);
                    
                }
            }
    }

    @FXML
    private void handleOnMouseClickedVolverMapaText(MouseEvent event) {
        ((Stage)((Node)event.getSource()).getScene().getWindow()).close();
    }
}
