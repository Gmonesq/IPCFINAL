/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Registro;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

/**
 * FXML Controller class
 *
 * @author kalez
 */
public class RegistroController implements Initializable {

    @FXML //Texto usuario
    private Text eusuarior;
    @FXML //Texto contraseña
    private Text epasswordr;
    @FXML //Texto fecha de nacimiento
    private Text eborn;
    @FXML //Texto email
    private Text eemail;
    @FXML //Cuadro de texto para instorducir usuario
    private TextField tusuarior;
    @FXML //cuadro de etxto para introducir contraseña
    private TextField tpasswordr;
    @FXML //Cuador de texto para introducir email
    private TextField temail;
    @FXML //Seleccionador de fecha de nacimiento
    private DatePicker edata;
    @FXML //Botón enviar
    private Button benviar;
    @FXML //Botón borrar
    private Button bborrar;
    @FXML //Botón seleccionar avatar
    private Button bavatar;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
