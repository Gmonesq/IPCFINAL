/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Intro;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

/**
 * FXML Controller class
 *
 * @author kalez
 */
public class IntroController implements Initializable {

    @FXML //Texto contraseña
    private Text epassword;
    @FXML //Cuadro de texto para introducir contraseña
    private PasswordField tpassword;
    @FXML //Cuadro de texto para introducir usuario
    private TextField tusuario;
    @FXML //Botón usuario
    private Button biniciar;
    @FXML //Botón registrarse
    private Button bregistrarse;
    @FXML //Texto usuario
    private Text eusuario;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
