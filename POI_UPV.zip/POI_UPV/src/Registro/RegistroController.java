/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Registro;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;

/**
 * FXML Controller class
 *
 * @author kalez
 */
public class RegistroController implements Initializable {
    
    @FXML //Botón seleccionar avatar
    private Button avatarBtn;
    @FXML
    private TextField userTextRegister;
    @FXML //cuadro de etxto para introducir contraseña
    private TextField passwordTextRegister;
    @FXML //Cuador de texto para introducir email
    private TextField emailTextRegister;
    @FXML //Seleccionador de fecha de nacimiento
    private DatePicker birthTextRegister;
    @FXML //Botón enviar
    private Button enviarBtnRegister;
    @FXML //Botón borrar
    private Button borrarBtnRegister;
    @FXML
    private Text userLabel;
    @FXML
    private Text passwordLabel;
    @FXML
    private Text birthLabel;
    @FXML
    private Text emailLabel;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void handleOnActionEnviarBtnRegister(ActionEvent event) {
    }

    @FXML
    private void handleOnActionBorrarBtnRegister(ActionEvent event) {
    }

    @FXML
    private void handleOnActionAvatarBtn(ActionEvent event) {
    }
    
}
