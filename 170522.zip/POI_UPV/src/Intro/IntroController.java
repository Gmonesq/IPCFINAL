/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Intro;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author kalez
 */
public class IntroController implements Initializable {

    @FXML //Texto contraseña
    private Text epassword;
    @FXML //Cuadro de texto para introducir contraseña
    private PasswordField tpassword;
    @FXML //Cuadro de texto para introducir usuario
    private TextField tusuario;
    @FXML //Botón usuario
    private Button biniciar;
    @FXML //Botón registrarse
    private Button bregistrarse;
    @FXML //Texto usuario
    private Text eusuario;
     
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void handleOnActionIniciarBtn(ActionEvent event) throws IOException{
        FXMLLoader myLoader = new FXMLLoader(getClass().getResource("/poiupv/Intro.fxml"));
        Parent root = myLoader.load();
        Scene scene = new Scene(root);
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.setTitle("Mapa");
        stage.show();
    }
    
}
